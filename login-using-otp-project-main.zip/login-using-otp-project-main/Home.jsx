import React, { useState } from 'react'

function Home() {
    return (
        <>
         {"WELCOME ! You've login successfully"}
        </>
    )
}

export default Home